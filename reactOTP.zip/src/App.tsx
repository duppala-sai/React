import { createRoot } from "react-dom/client";
import OtpLogin from "./components/OtpLogin";

const root = createRoot(document.getElementById("root") as HTMLElement);

root.render(
  <>
    <OtpLogin />
  </>
);
